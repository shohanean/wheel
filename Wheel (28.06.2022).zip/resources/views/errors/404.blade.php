<a href="{{ url('/') }}">
    <img width="100%" src="{{ asset('winwheel/404.jpg') }}" alt="">
</a>
