<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    ভাগ্যবানদের তালিকা
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-bordered table-hover text-center">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Phone Number</th>
                                <th scope="col">Interested In</th>
                                <th scope="col">Code</th>
                                <th scope="col">Used Status</th>
                                <th scope="col">Discount</th>
                                <th scope="col">Code Generated At</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $wheels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wheel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row" class="text-center"><?php echo e($loop->index+1); ?></th>
                                    <td><i class="lni lni-phone"></i> <?php echo e($wheel->phone_number); ?></td>
                                    <td>
                                        <i class="<?php echo e(($wheel->course_type == 'online') ? 'lni lni-headphone-alt':'lni lni-map'); ?>"></i>
                                        <?php echo e($wheel->course_type); ?>

                                    </td>
                                    <td>
                                        <script>
                                            function copytoclipboard(e) {
                                                var copyText = e.value;
                                                navigator.clipboard.writeText(copyText);
                                            }
                                        </script>
                                        <?php echo e($wheel->code); ?>

                                        <button value="<?php echo e($wheel->code); ?>" onclick="copytoclipboard(this)" class="btn btn-outline-primary"><i class="lni lni-files"></i></button>
                                    </td>
                                    <td>
                                        <?php if($wheel->used_status): ?>
                                            <span class="badge bg-success">Used</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Not Used Yet</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($wheel->discount ?? '-'); ?></td>
                                    <td>
                                        <div class="badge bg-info text-dark">
                                            <?php echo e($wheel->created_at->diffforhumans()); ?>

                                        </div>
                                        <br>
                                        Date: <?php echo e($wheel->created_at->format('d/m/Y')); ?>

                                        <br>
                                        Time: <?php echo e($wheel->created_at->format('H:i:s A')); ?>

                                    </td>
                                    <td>
                                        <?php if(!$wheel->used_status): ?>
                                            <a href="<?php echo e(url('resend/code')); ?>/<?php echo e($wheel->id); ?>" class="btn btn-sm btn-warning">Resend Code</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dept. Head (Web)\Desktop\wheel\resources\views/home.blade.php ENDPATH**/ ?>