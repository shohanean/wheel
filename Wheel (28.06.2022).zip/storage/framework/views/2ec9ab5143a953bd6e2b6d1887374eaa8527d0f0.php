<a href="<?php echo e(url('/')); ?>">
    <img width="100%" src="<?php echo e(asset('winwheel/404.jpg')); ?>" alt="">
</a>
<?php /**PATH C:\Users\Dept. Head (Web)\Desktop\wheel\resources\views/errors/404.blade.php ENDPATH**/ ?>